import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Book {
    private String title;
    private String author;
    private int availableCopies;

    public Book(String title, String author, int availableCopies) {
        this.title = title;
        this.author = author;
        this.availableCopies = availableCopies;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    public void decreaseAvailableCopies() {
        if (availableCopies > 0) {
            availableCopies--;
        } else {
            System.out.println("No available copies of " + title + " by " + author + " left.");
        }
    }

    public void increaseAvailableCopies() {
        availableCopies++;
    }
}

class Library {
    private List<Book> books;

    public Library() {
        this.books = new ArrayList<>();
        initializeLibrary();
    }

    private void initializeLibrary() {
        // Hardcoded initial books (replace with actual data or database)
        books.add(new Book("Book1", "Author1", 5));
        books.add(new Book("Book2", "Author2", 3));
        books.add(new Book("Book3", "Author3", 8));
    }

    public void displayBooks() {
        System.out.println("Library Books:");
        for (Book book : books) {
            System.out.println(book.getTitle() + " by " + book.getAuthor() +
                    " - Available Copies: " + book.getAvailableCopies());
        }
        System.out.println();
    }

    public Book findBook(String title, String author) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title) && book.getAuthor().equalsIgnoreCase(author)) {
                return book;
            }
        }
        return null;
    }
}

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Display Books");
            System.out.println("2. Borrow Book");
            System.out.println("3. Return Book");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    library.displayBooks();
                    break;
                case 2:
                    borrowBook(library, scanner);
                    break;
                case 3:
                    returnBook(library, scanner);
                    break;
                case 4:
                    System.out.println("Exiting the program. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    private static void borrowBook(Library library, Scanner scanner) {
        System.out.print("Enter the title of the book you want to borrow: ");
        String title = scanner.nextLine();

        System.out.print("Enter the author of the book: ");
        String author = scanner.nextLine();

        Book book = library.findBook(title, author);

        if (book != null) {
            book.decreaseAvailableCopies();
            System.out.println("You have successfully borrowed " + title + " by " + author + ".");
        } else {
            System.out.println("Book not found in the library.");
        }
    }

    private static void returnBook(Library library, Scanner scanner) {
        System.out.print("Enter the title of the book you want to return: ");
        String title = scanner.nextLine();

        System.out.print("Enter the author of the book: ");
        String author = scanner.nextLine();

        Book book = library.findBook(title, author);

        if (book != null) {
            book.increaseAvailableCopies();
            System.out.println("You have successfully returned " + title + " by " + author + ".");
        } else {
            System.out.println("Book not found in the library.");
        }
    }
}
